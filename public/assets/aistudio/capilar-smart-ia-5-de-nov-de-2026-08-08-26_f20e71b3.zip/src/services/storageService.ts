/**
 * Serviço de Armazenamento Seguro de Fotografias e Tricoscopia (Firebase Storage + Firestore)
 * Capilar Smart IA — Fase 4.1
 * 
 * Condições Técnicas Rigorosas:
 * 1. Subpastas granulares: thumbs/ (<=500KB), optimized/ (<=3MB), originals/ (<=25MB).
 * 2. Cancelamento real compatível com Firebase Storage SDK via UploadTask.cancel().
 * 3. Recuperação idempotente por artefato (não duplica arquivos já transmitidos).
 * 4. Prevenção e limpeza de artefatos órfãos.
 * 5. IndexedDB isolado estritamente por UID (capilar_smart_storage_{uid}).
 * 6. Compatibilidade de leitura com fotografias legadas da Fase 4.
 */

import {
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
  getBytes,
  UploadTask,
} from 'firebase/storage';
import { useState, useEffect, useRef, useCallback } from 'react';
import { storage, requireStorage, isFirebaseConfigured, auth } from './firebase';
import {
  ClientPhotoRecord,
  PhotoCategory,
  CoordinatedDeletionRecord,
  PhotoArtifactsTracking,
  MAX_CLINICAL_ORIGINAL_BYTES,
  MAX_CLINICAL_OPTIMIZED_BYTES,
  MAX_CLINICAL_THUMBNAIL_BYTES,
  UseSecurePhotoOptions,
  UseSecurePhotoResult,
} from '../types';
import { processClinicalImage } from '../utils/imageCompressor';
import {
  savePhotoMetadataToFirestore,
  fetchPhotosByClientFromFirestore,
  deletePhotoMetadataFromFirestore,
} from './firestoreData';

// ==========================================
// 1. ISOLAMENTO DE INDEXEDDB POR UID
// ==========================================

const getDbNameForUser = (uid: string): string => {
  if (!uid) throw new Error('[StorageService] UID obrigatório para instanciar armazenamento local isolado.');
  return `capilar_smart_storage_${uid}`;
};

const openUserIndexedDB = (uid: string): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB não suportado neste navegador.'));
    }

    const dbName = getDbNameForUser(uid);
    const request = window.indexedDB.open(dbName, 2);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const idb = (event.target as IDBOpenDBRequest).result;
      if (!idb.objectStoreNames.contains('pending_uploads')) {
        idb.createObjectStore('pending_uploads', { keyPath: 'id' });
      }
      if (!idb.objectStoreNames.contains('pending_deletions')) {
        idb.createObjectStore('pending_deletions', { keyPath: 'photoId' });
      }
      if (!idb.objectStoreNames.contains('cached_photos')) {
        idb.createObjectStore('cached_photos', { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

// ==========================================
// 2. ESTRUTURA DE PENDÊNCIAS COM RASTREAMENTO POR ARTEFATO
// ==========================================

export interface PendingUploadItem {
  id: string;
  clientId: string;
  professionalId: string;
  evaluationId?: string;
  category: PhotoCategory;
  notes?: string;
  observedRegion?: string;
  deviceFindings?: string[];
  consentRecordId?: string;
  takenAt: string;
  createdAt: string;
  
  artifacts: PhotoArtifactsTracking;
  
  originalBlob: Blob;
  originalExtension: string;
  optimizedBlob: Blob;
  thumbnailBlob: Blob;
  width: number;
  height: number;
  fileSizeBytes: number;
  originalSizeBytes: number;
  retryCount: number;
}

// Registro global de UploadTasks ativas para cancelamento real pelo SDK
const activeUploadTasks = new Map<string, UploadTask>();

export const abortActiveUploads = () => {
  if (activeUploadTasks.size > 0) {
    console.info(`[StorageService] Cancelando ${activeUploadTasks.size} UploadTask(s) ativas por logout.`);
    activeUploadTasks.forEach((task, key) => {
      try {
        task.cancel();
        console.info(`[StorageService] UploadTask cancelada: ${key}`);
      } catch (err) {
        console.warn(`[StorageService] Erro ao cancelar tarefa ${key}:`, err);
      }
    });
    activeUploadTasks.clear();
  }
  revokeAllTrackedBlobUrls();
};

// ==========================================
// 3. UPLOAD COM PRESERVAÇÃO E RECUPERAÇÃO IDEMPOTENTE
// ==========================================

export interface UploadPhotoParams {
  fileOrBlob: File | Blob;
  clientId: string;
  professionalId: string;
  category: PhotoCategory;
  evaluationId?: string;
  notes?: string;
  observedRegion?: string;
  deviceFindings?: string[];
  consentRecordId?: string;
  onProgress?: (percent: number) => void;
}

export const uploadClinicalPhoto = async ({
  fileOrBlob,
  clientId,
  professionalId,
  category,
  evaluationId,
  notes,
  observedRegion,
  deviceFindings,
  consentRecordId,
  onProgress,
}: UploadPhotoParams): Promise<ClientPhotoRecord> => {
  if (!professionalId) throw new Error('[StorageService] professionalId é obrigatório para upload.');
  if (!clientId) throw new Error('[StorageService] clientId é obrigatório para vincular a fotografia.');

  const photoId = `photo_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const takenAt = new Date().toISOString();
  const createdAt = takenAt;

  // 1. Processamento e validação de limite (25 MB)
  const processed = await processClinicalImage(fileOrBlob, category);

  // Novos subcaminhos granulares especializados (Fase 4.1)
  const thumbPath = `photos/${professionalId}/clients/${clientId}/thumbs/${photoId}_thumb.webp`;
  const fullPath = `photos/${professionalId}/clients/${clientId}/optimized/${photoId}_full.webp`;
  const origPath = `photos/${professionalId}/clients/${clientId}/originals/${photoId}_orig.${processed.originalExtension}`;

  const artifacts: PhotoArtifactsTracking = {
    thumbnail: {
      storagePath: thumbPath,
      status: 'PENDING',
      fileSizeBytes: processed.thumbnailSizeBytes,
    },
    optimized: {
      storagePath: fullPath,
      status: 'PENDING',
      fileSizeBytes: processed.optimizedSizeBytes,
    },
    original: {
      storagePath: origPath,
      status: 'PENDING',
      fileSizeBytes: processed.originalSizeBytes,
    },
  };

  // Se o Firebase estiver indisponível ou offline, enfileira no IndexedDB do usuário
  if (!isFirebaseConfigured() || !storage) {
    console.warn('[StorageService] Firebase Storage offline/não configurado. Gravando em IndexedDB isolado do usuário.');
    const pendingItem: PendingUploadItem = {
      id: photoId,
      clientId,
      professionalId,
      evaluationId,
      category,
      notes,
      observedRegion,
      deviceFindings,
      consentRecordId,
      takenAt,
      createdAt,
      artifacts,
      originalBlob: processed.originalBlob,
      originalExtension: processed.originalExtension,
      optimizedBlob: processed.optimizedBlob,
      thumbnailBlob: processed.thumbnailBlob,
      width: processed.width,
      height: processed.height,
      fileSizeBytes: processed.optimizedSizeBytes,
      originalSizeBytes: processed.originalSizeBytes,
      retryCount: 0,
    };

    const idb = await openUserIndexedDB(professionalId);
    await new Promise<void>((resolve, reject) => {
      const tx = idb.transaction('pending_uploads', 'readwrite');
      tx.objectStore('pending_uploads').put(pendingItem);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });

    const localRecord: ClientPhotoRecord = {
      id: photoId,
      clientId,
      evaluationId,
      professionalId,
      category,
      storagePath: fullPath,
      thumbStoragePath: thumbPath,
      originalStoragePath: origPath,
      downloadUrl: URL.createObjectURL(processed.optimizedBlob),
      thumbnailUrl: URL.createObjectURL(processed.thumbnailBlob),
      originalDownloadUrl: URL.createObjectURL(processed.originalBlob),
      width: processed.width,
      height: processed.height,
      fileSizeBytes: processed.optimizedSizeBytes,
      originalSizeBytes: processed.originalSizeBytes,
      isOriginalPreserved: true,
      notes,
      observedRegion,
      deviceFindings,
      consentRecordId,
      takenAt,
      createdAt,
      syncStatus: 'PENDING_UPLOAD',
    };

    return localRecord;
  }

  // Upload em Nuvem com controle individual por artefato e UploadTask
  const storageInstance = requireStorage();

  const customMetadata = {
    clientId,
    professionalId,
    category,
    photoId,
    takenAt,
  };

  try {
    // A. Miniatura WebP (<= 500 KB)
    if (artifacts.thumbnail.status !== 'CONFIRMED') {
      const thumbRef = ref(storageInstance, thumbPath);
      const thumbTask = uploadBytesResumable(thumbRef, processed.thumbnailBlob, {
        contentType: 'image/webp',
        customMetadata,
      });
      activeUploadTasks.set(`${photoId}_thumb`, thumbTask);
      await thumbTask;
      activeUploadTasks.delete(`${photoId}_thumb`);
      artifacts.thumbnail.downloadUrl = await getDownloadURL(thumbRef);
      artifacts.thumbnail.status = 'CONFIRMED';
      onProgress?.(30);
    }

    // B. Imagem Otimizada WebP (<= 3 MB)
    if (artifacts.optimized.status !== 'CONFIRMED') {
      const fullRef = ref(storageInstance, fullPath);
      const fullUploadTask = uploadBytesResumable(fullRef, processed.optimizedBlob, {
        contentType: 'image/webp',
        customMetadata,
      });
      activeUploadTasks.set(`${photoId}_optimized`, fullUploadTask);

      fullUploadTask.on('state_changed', (snapshot) => {
        if (snapshot.totalBytes > 0) {
          const percent = 30 + Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 40);
          onProgress?.(percent);
        }
      });

      await fullUploadTask;
      activeUploadTasks.delete(`${photoId}_optimized`);
      artifacts.optimized.downloadUrl = await getDownloadURL(fullRef);
      artifacts.optimized.status = 'CONFIRMED';
      onProgress?.(70);
    }

    // C. Fotografia Original Bruta Clínica (<= 25 MB)
    if (artifacts.original.status !== 'CONFIRMED') {
      const origMime = processed.originalBlob.type || 'image/jpeg';
      const origRef = ref(storageInstance, origPath);
      const origTask = uploadBytesResumable(origRef, processed.originalBlob, {
        contentType: origMime,
        customMetadata,
      });
      activeUploadTasks.set(`${photoId}_orig`, origTask);

      origTask.on('state_changed', (snapshot) => {
        if (snapshot.totalBytes > 0) {
          const percent = 70 + Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 28);
          onProgress?.(percent);
        }
      });

      await origTask;
      activeUploadTasks.delete(`${photoId}_orig`);
      artifacts.original.downloadUrl = await getDownloadURL(origRef);
      artifacts.original.status = 'CONFIRMED';
      onProgress?.(100);
    }

    // D. Gravação dos Metadados no Cloud Firestore
    const record: ClientPhotoRecord = {
      id: photoId,
      clientId,
      evaluationId,
      professionalId,
      category,
      storagePath: fullPath,
      thumbStoragePath: thumbPath,
      originalStoragePath: origPath,
      downloadUrl: artifacts.optimized.downloadUrl || '',
      thumbnailUrl: artifacts.thumbnail.downloadUrl || '',
      originalDownloadUrl: artifacts.original.downloadUrl || '',
      width: processed.width,
      height: processed.height,
      fileSizeBytes: processed.optimizedSizeBytes,
      originalSizeBytes: processed.originalSizeBytes,
      isOriginalPreserved: true,
      notes,
      observedRegion,
      deviceFindings,
      consentRecordId,
      takenAt,
      createdAt,
      syncStatus: 'SYNCED',
    };

    await savePhotoMetadataToFirestore(record, professionalId);

    // Cache não-crítico
    try {
      const idb = await openUserIndexedDB(professionalId);
      const tx = idb.transaction('cached_photos', 'readwrite');
      tx.objectStore('cached_photos').put(record);
    } catch {
      // ignore
    }

    return record;
  } catch (err: unknown) {
    const errorObj = err as { code?: string; message?: string };
    
    // Tratamento de cancelamento gracioso pelo SDK
    if (errorObj?.code === 'storage/canceled') {
      console.info(`[StorageService] Upload de ${photoId} cancelado pelo SDK.`);
    } else {
      console.error('[StorageService] Erro no upload em nuvem. Gravando pendência idempotente no IndexedDB:', err);
    }

    // Limpa referências ativas de tarefas dessa foto
    activeUploadTasks.delete(`${photoId}_thumb`);
    activeUploadTasks.delete(`${photoId}_optimized`);
    activeUploadTasks.delete(`${photoId}_orig`);

    // Salva estado parcial no IndexedDB com status de cada artefato já gravado
    const pendingItem: PendingUploadItem = {
      id: photoId,
      clientId,
      professionalId,
      evaluationId,
      category,
      notes,
      observedRegion,
      deviceFindings,
      consentRecordId,
      takenAt,
      createdAt,
      artifacts,
      originalBlob: processed.originalBlob,
      originalExtension: processed.originalExtension,
      optimizedBlob: processed.optimizedBlob,
      thumbnailBlob: processed.thumbnailBlob,
      width: processed.width,
      height: processed.height,
      fileSizeBytes: processed.optimizedSizeBytes,
      originalSizeBytes: processed.originalSizeBytes,
      retryCount: 0,
    };

    try {
      const idb = await openUserIndexedDB(professionalId);
      const tx = idb.transaction('pending_uploads', 'readwrite');
      tx.objectStore('pending_uploads').put(pendingItem);
    } catch {
      // ignore
    }

    throw err;
  }
};

// ==========================================
// 4. EXCLUSÃO COORDENADA COM LIMPEZA DE ÓRFÃOS
// ==========================================

export const coordinatedDeletePhoto = async (
  photo: ClientPhotoRecord,
  professionalId: string
): Promise<CoordinatedDeletionRecord> => {
  if (!professionalId) throw new Error('[StorageService] professionalId é obrigatório para exclusão.');
  if (photo.professionalId !== professionalId) {
    throw new Error('[StorageService] Tentativa de exclusão não autorizada: professionalId incompatível.');
  }

  const deletionRecord: CoordinatedDeletionRecord = {
    id: `del_${Date.now()}_${photo.id}`,
    photoId: photo.id,
    professionalId,
    clientId: photo.clientId,
    storagePaths: [
      photo.storagePath,
      photo.thumbStoragePath || '',
      photo.originalStoragePath || '',
    ].filter(Boolean),
    requestedAt: new Date().toISOString(),
    retryCount: 0,
    status: 'PENDING_STORAGE',
  };

  if (!isFirebaseConfigured() || !storage) {
    try {
      const idb = await openUserIndexedDB(professionalId);
      const tx = idb.transaction(['pending_uploads', 'cached_photos'], 'readwrite');
      tx.objectStore('pending_uploads').delete(photo.id);
      tx.objectStore('cached_photos').delete(photo.id);
      deletionRecord.status = 'CONFIRMED';
      deletionRecord.confirmedAt = new Date().toISOString();
      return deletionRecord;
    } catch (e) {
      deletionRecord.status = 'FAILED';
      deletionRecord.lastError = String(e);
      return deletionRecord;
    }
  }

  const storageInstance = requireStorage();

  // 1. Remoção tolerante no Storage (suporta tanto caminhos granulares quanto legados)
  for (const path of deletionRecord.storagePaths) {
    try {
      const fileRef = ref(storageInstance, path);
      await deleteObject(fileRef);
    } catch (err: unknown) {
      const errorObj = err as { code?: string };
      if (errorObj?.code !== 'storage/object-not-found') {
        console.warn(`[StorageService] Falha transitória ao excluir ${path}:`, err);
        deletionRecord.lastError = `Falha ao remover arquivo do Storage: ${path}`;
      }
    }
  }

  // 2. Remoção no Firestore
  deletionRecord.status = 'PENDING_FIRESTORE';
  try {
    await deletePhotoMetadataFromFirestore(photo.id, professionalId);
    deletionRecord.status = 'CONFIRMED';
    deletionRecord.confirmedAt = new Date().toISOString();

    // 3. Limpeza local
    try {
      const idb = await openUserIndexedDB(professionalId);
      const tx = idb.transaction(['pending_uploads', 'cached_photos', 'pending_deletions'], 'readwrite');
      tx.objectStore('pending_uploads').delete(photo.id);
      tx.objectStore('cached_photos').delete(photo.id);
      tx.objectStore('pending_deletions').delete(photo.id);
    } catch {
      // ignore
    }

    return deletionRecord;
  } catch (err: unknown) {
    console.error('[StorageService] Falha ao excluir metadados no Firestore. Registrando pendência:', err);
    deletionRecord.status = 'FAILED';
    deletionRecord.lastError = `Metadados do Firestore não removidos: ${String(err)}`;

    try {
      const idb = await openUserIndexedDB(professionalId);
      const tx = idb.transaction('pending_deletions', 'readwrite');
      tx.objectStore('pending_deletions').put(deletionRecord);
    } catch {
      // ignore
    }

    throw err;
  }
};

// ==========================================
// 5. RECUPERAÇÃO E SINCRONIZAÇÃO OFFLINE TRANSPARENTE
// ==========================================

export const fetchClientPhotosWithOfflineSupport = async (
  clientId: string,
  professionalId: string
): Promise<ClientPhotoRecord[]> => {
  if (!professionalId || !clientId) return [];

  let cloudPhotos: ClientPhotoRecord[] = [];
  try {
    cloudPhotos = await fetchPhotosByClientFromFirestore(clientId, professionalId);
  } catch (err) {
    console.warn('[StorageService] Falha ao consultar nuvem. Consultando IndexedDB local:', err);
  }

  // Consulta IndexedDB isolado do usuário
  try {
    const idb = await openUserIndexedDB(professionalId);
    const pendingList: ClientPhotoRecord[] = await new Promise((resolve) => {
      const tx = idb.transaction('pending_uploads', 'readonly');
      const store = tx.objectStore('pending_uploads');
      const req = store.getAll();
      req.onsuccess = () => {
        const raw = (req.result || []) as PendingUploadItem[];
        const filtered = raw
          .filter((item) => item.professionalId === professionalId && item.clientId === clientId)
          .map((item) => ({
            id: item.id,
            clientId: item.clientId,
            evaluationId: item.evaluationId,
            professionalId: item.professionalId,
            category: item.category,
            storagePath: item.artifacts?.optimized?.storagePath || `photos/${professionalId}/clients/${clientId}/optimized/${item.id}_full.webp`,
            thumbStoragePath: item.artifacts?.thumbnail?.storagePath || `photos/${professionalId}/clients/${clientId}/thumbs/${item.id}_thumb.webp`,
            originalStoragePath: item.artifacts?.original?.storagePath || `photos/${professionalId}/clients/${clientId}/originals/${item.id}_orig.${item.originalExtension}`,
            downloadUrl: item.artifacts?.optimized?.downloadUrl || URL.createObjectURL(item.optimizedBlob),
            thumbnailUrl: item.artifacts?.thumbnail?.downloadUrl || URL.createObjectURL(item.thumbnailBlob),
            originalDownloadUrl: item.artifacts?.original?.downloadUrl || URL.createObjectURL(item.originalBlob),
            width: item.width,
            height: item.height,
            fileSizeBytes: item.fileSizeBytes,
            originalSizeBytes: item.originalSizeBytes,
            isOriginalPreserved: true,
            notes: item.notes,
            observedRegion: item.observedRegion,
            deviceFindings: item.deviceFindings,
            consentRecordId: item.consentRecordId,
            takenAt: item.takenAt,
            createdAt: item.createdAt,
            syncStatus: 'PENDING_UPLOAD' as const, // Sinalização explícita: Salvo apenas localmente
          }));
        resolve(filtered);
      };
      req.onerror = () => resolve([]);
    });

    // Unifica nuvem e pendências locais (evitando duplicatas)
    const combined = [...pendingList];
    const seenIds = new Set(pendingList.map((p) => p.id));
    for (const cp of cloudPhotos) {
      if (!seenIds.has(cp.id)) {
        combined.push({
          ...cp,
          syncStatus: 'SYNCED' as const, // Confirmado em nuvem
        });
        seenIds.add(cp.id);
      }
    }

    return combined.sort((a, b) => new Date(b.takenAt || b.createdAt).getTime() - new Date(a.takenAt || a.createdAt).getTime());
  } catch {
    return cloudPhotos.map((p) => ({ ...p, syncStatus: 'SYNCED' as const }));
  }
};

// ==========================================
// 8. FASE 4.2: SEGURANÇA AVANÇADA DE FOTOGRAFIAS E CICLO DE VIDA DE BLOBS
// ==========================================

export const getApiBaseUrl = (): string => {
  return (import.meta.env.VITE_API_BASE_URL || '').replace(/\/+$/, '');
};

// Registro global de Blob URLs ativas para revogação em logout / encerramento
const globalActiveBlobUrls = new Set<string>();

export const trackActiveBlobUrl = (url: string) => {
  if (url && url.startsWith('blob:')) {
    globalActiveBlobUrls.add(url);
  }
};

export const releaseActiveBlobUrl = (url: string) => {
  if (url && globalActiveBlobUrls.has(url)) {
    try {
      URL.revokeObjectURL(url);
    } catch {
      // Ignora erro se já revogado
    }
    globalActiveBlobUrls.delete(url);
  }
};

export const revokeAllTrackedBlobUrls = () => {
  if (globalActiveBlobUrls.size > 0) {
    console.info(`[StorageService] Revogando ${globalActiveBlobUrls.size} Blob URL(s) ativas.`);
    globalActiveBlobUrls.forEach((url) => {
      try {
        URL.revokeObjectURL(url);
      } catch {
        // Ignora
      }
    });
    globalActiveBlobUrls.clear();
  }
};

/**
 * Decodifica e valida caminho de foto legada a partir de downloadUrl
 * Aplica proteção Anti-SSRF:
 * 1. Domínio restrito a firebasestorage.googleapis.com ou emulador local
 * 2. Decodificação única estrita
 * 3. Bloqueio de sequências de travessia (..) e caracteres nulos (\0)
 * 4. Validação do prefixo obrigatório: photos/{callerUid}/clients/{expectedClientId}/
 */
export const decodeAndValidateLegacyStoragePath = (
  rawUrl: string,
  callerUid: string,
  expectedClientId: string
): string | null => {
  if (!rawUrl || typeof rawUrl !== 'string') return null;

  try {
    const parsed = new URL(rawUrl);
    const isOfficialDomain = parsed.hostname === 'firebasestorage.googleapis.com';
    const isEmulatorDomain = parsed.hostname === '127.0.0.1' || parsed.hostname === 'localhost';

    if (!isOfficialDomain && !isEmulatorDomain) {
      console.warn('[StorageService] Domínio de storage não autorizado rejeitado (Anti-SSRF):', parsed.hostname);
      return null;
    }

    const oIndex = parsed.pathname.indexOf('/o/');
    if (oIndex === -1) return null;

    const rawPathPart = parsed.pathname.substring(oIndex + 3);
    const decodedPath = decodeURIComponent(rawPathPart);

    if (
      decodedPath.includes('..') ||
      decodedPath.includes('//') ||
      decodedPath.includes('\\') ||
      decodedPath.includes('\0')
    ) {
      console.warn('[StorageService] Caminho malicioso com travessia ou caractere nulo rejeitado:', decodedPath);
      return null;
    }

    const expectedPrefix = `photos/${callerUid}/clients/${expectedClientId}/`;
    if (!decodedPath.startsWith(expectedPrefix)) {
      console.warn('[StorageService] Caminho não coincide com UID e ClientId autorizados:', {
        decodedPath,
        expectedPrefix,
      });
      return null;
    }

    return decodedPath;
  } catch (err) {
    console.warn('[StorageService] Falha ao decodificar URL legada:', err);
    return null;
  }
};

/**
 * Busca bytes no Firebase Storage via getBytes() com limite estrito
 * ou resolve do IndexedDB local se em modo offline
 */
export const fetchSecureBlob = async ({
  storagePath,
  fallbackUrl,
  callerUid,
  expectedClientId,
  maxSizeBytes = MAX_CLINICAL_OPTIMIZED_BYTES,
}: {
  storagePath?: string;
  fallbackUrl?: string;
  callerUid: string;
  expectedClientId: string;
  maxSizeBytes?: number;
}): Promise<Blob> => {
  let resolvedPath = storagePath;

  if (!resolvedPath && fallbackUrl) {
    resolvedPath = decodeAndValidateLegacyStoragePath(fallbackUrl, callerUid, expectedClientId) || undefined;
  }

  if (!resolvedPath) {
    throw new Error('[StorageService] Caminho de armazenamento clínico não localizado ou inválido.');
  }

  if (!resolvedPath.startsWith(`photos/${callerUid}/clients/${expectedClientId}/`)) {
    throw new Error('[StorageService] Violação de isolamento multi-tenant de caminho.');
  }

  if (isFirebaseConfigured() && storage) {
    const storageRef = ref(storage, resolvedPath);
    // getBytes aplica o limite prévio antes de transmitir o payload
    const arrayBuffer = await getBytes(storageRef, maxSizeBytes);
    const mimeType = resolvedPath.endsWith('.webp')
      ? 'image/webp'
      : resolvedPath.endsWith('.png')
      ? 'image/png'
      : 'image/jpeg';
    return new Blob([arrayBuffer], { type: mimeType });
  }

  // Fallback offline via IndexedDB do usuário
  const idb = await openUserIndexedDB(callerUid);
  return new Promise((resolve, reject) => {
    const tx = idb.transaction('pending_uploads', 'readonly');
    const store = tx.objectStore('pending_uploads');
    const req = store.getAll();
    req.onsuccess = () => {
      const items = (req.result || []) as PendingUploadItem[];
      const match = items.find(
        (i) =>
          i.artifacts?.optimized?.storagePath === resolvedPath ||
          i.artifacts?.thumbnail?.storagePath === resolvedPath ||
          i.artifacts?.original?.storagePath === resolvedPath
      );
      if (match) {
        if (resolvedPath && resolvedPath.includes('thumb')) return resolve(match.thumbnailBlob);
        if (resolvedPath && resolvedPath.includes('orig')) return resolve(match.originalBlob);
        return resolve(match.optimizedBlob);
      }
      reject(new Error('[StorageService] Artefato não encontrado no armazenamento local offline.'));
    };
    req.onerror = () => reject(req.error);
  });
};

/**
 * Hook React Especializado para Gerenciamento de Blobs Efêmeros (Fase 4.2)
 * Proteções:
 * 1. Limite estrito de bytes antes do download
 * 2. Revogação de Blob anterior na troca de cliente (anti-corrida)
 * 3. Descarte de Blob imediato se o componente for desmontado antes de carregar
 * 4. Compatível com iPadOS/Safari
 */
export const useSecurePhoto = ({
  storagePath,
  fallbackUrl,
  clientId,
  photoId,
  maxSizeBytes = MAX_CLINICAL_OPTIMIZED_BYTES,
  isOriginal = false,
}: UseSecurePhotoOptions): UseSecurePhotoResult => {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const activeClientIdRef = useRef<string>(clientId);
  const activeBlobUrlRef = useRef<string | null>(null);
  const requestIdRef = useRef<number>(0);

  useEffect(() => {
    activeClientIdRef.current = clientId;
  }, [clientId]);

  const loadPhoto = useCallback(async () => {
    const currentRequestId = ++requestIdRef.current;
    setIsLoading(true);
    setError(null);

    // Se houver Blob antigo ativo para outra imagem, revoga imediatamente
    if (activeBlobUrlRef.current) {
      releaseActiveBlobUrl(activeBlobUrlRef.current);
      activeBlobUrlRef.current = null;
      setBlobUrl(null);
    }

    const currentUid = auth?.currentUser?.uid || '';
    if (!currentUid || !clientId) {
      setIsLoading(false);
      return;
    }

    try {
      const blob = await fetchSecureBlob({
        storagePath,
        fallbackUrl,
        callerUid: currentUid,
        expectedClientId: clientId,
        maxSizeBytes,
      });

      // Se durante o carregamento assíncrono o usuário mudou de cliente ou disparou outra requisição:
      if (
        currentRequestId !== requestIdRef.current ||
        activeClientIdRef.current !== clientId
      ) {
        // Não aplica ao estado e não cria URL
        return;
      }

      const newUrl = URL.createObjectURL(blob);
      trackActiveBlobUrl(newUrl);
      activeBlobUrlRef.current = newUrl;
      setBlobUrl(newUrl);
    } catch (err: unknown) {
      if (currentRequestId === requestIdRef.current) {
        const msg = (err as Error)?.message || 'Falha ao carregar imagem segura.';
        setError(msg);
      }
    } finally {
      if (currentRequestId === requestIdRef.current) {
        setIsLoading(false);
      }
    }
  }, [storagePath, fallbackUrl, clientId, maxSizeBytes]);

  useEffect(() => {
    loadPhoto();

    return () => {
      if (activeBlobUrlRef.current) {
        releaseActiveBlobUrl(activeBlobUrlRef.current);
        activeBlobUrlRef.current = null;
      }
    };
  }, [loadPhoto]);

  return {
    blobUrl,
    isLoading,
    error,
    reload: loadPhoto,
  };
};

/**
 * Download Seguro de Laudo Fotográfico Original (Até 25 MiB)
 * Comunica-se exclusivamente via rota privada autenticada no backend
 */
export const downloadClinicalOriginalSecurely = async ({
  photoId,
  suggestedFilename,
}: {
  photoId: string;
  suggestedFilename?: string;
}): Promise<void> => {
  const token = auth?.currentUser ? await auth.currentUser.getIdToken() : '';
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/photos/${encodeURIComponent(photoId)}/original`;

  const headers: Record<string, string> = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    method: 'GET',
    headers,
  });

  if (!response.ok) {
    let errorMsg = `Erro ${response.status} ao baixar laudo original.`;
    try {
      const json = await response.json();
      if (json.error) errorMsg = json.error;
    } catch {
      // Ignora erro de JSON
    }
    throw new Error(errorMsg);
  }

  let filename = suggestedFilename || `laudo_original_${photoId}.jpg`;
  const disposition = response.headers.get('Content-Disposition');
  if (disposition) {
    const match = disposition.match(/filename="?([^"]+)"?/);
    if (match && match[1]) {
      filename = match[1];
    }
  }

  const blob = await response.blob();
  const downloadUrl = URL.createObjectURL(blob);

  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);

  setTimeout(() => {
    URL.revokeObjectURL(downloadUrl);
  }, 10000);
};
