import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { initializeApp, getApps, cert, type App } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";
import { getStorage } from "firebase-admin/storage";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "15mb" }));

// Middleware de CORS para compatibilidade com deploy distribuído (Netlify / Cloud Run)
app.use((req, res, next) => {
  const origin = req.headers.origin;
  const allowedOrigins = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    process.env.APP_URL,
    process.env.ALLOWED_ORIGIN,
  ].filter(Boolean) as string[];

  if (
    origin &&
    (allowedOrigins.includes(origin) ||
      origin.endsWith(".netlify.app") ||
      origin.endsWith(".run.app") ||
      origin.startsWith("http://localhost:") ||
      origin.startsWith("http://127.0.0.1:"))
  ) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Authorization, Content-Type, Content-Disposition"
    );
    res.setHeader(
      "Access-Control-Expose-Headers",
      "Content-Disposition, Content-Length"
    );
  }

  if (req.method === "OPTIONS") {
    return res.sendStatus(204);
  }
  next();
});

// Initialize Gemini client lazily/safely
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  if (!genAIClient) {
    genAIClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return genAIClient;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    aiEnabled: Boolean(process.env.GEMINI_API_KEY),
  });
});

// AI analysis endpoint for Capilar Smart IA
app.post("/api/ai-analysis", async (req, res) => {
  try {
    const { client, anamnese, visual, scores } = req.body;

    const ai = getGenAI();
    if (!ai) {
      // Graceful fallback with rich deterministic response if API key is not yet set
      return res.json({
        source: "engine",
        summary: `Avaliação cosmética para ${client?.name || "a cliente"}: Cabelo com curvatura ${visual?.curvature || "definida"}, apresentando necessidade predominante de ${scores?.topNeed || "Tratamento Intensivo"}. Fibras com porosidade ${visual?.porosity || "moderada"} e elasticidade ${visual?.elasticity || "regular"}. Indicado protocolo de reequilíbrio lipídico e hídrico imediato.`,
        professionalInsight: "Priorizar acidificação prévia em lavatório para alinhamento cuticular caso haja histórico químico recente. Evitar tração mecânica excessiva com escovas metálicas durante a secagem.",
        cronogramaSchedule: ["Hidratação", "Nutrição", "Hidratação", "Reconstrução"],
        homeCareTip: "Adotar protetor térmico sem enxágue com filtro UV e manter temperatura da água morna a fria no enxágue final para potencializar o brilho.",
      });
    }

    const prompt = `Você é uma especialista em Tricologia Cosmética e Cosmetologia Capilar Avançada atuando como assistente virtual no aplicativo "CAPILAR SMART IA", desenvolvido como Projeto Integrador do curso de Cabeleireiro do SENAC.
IMPORTANTE: Não faça diagnóstico médico ou dermatológico de patologias. Trate estritamente de estética, saúde da haste capilar, cosmetologia e protocolos de salão.

Dados da Cliente:
- Nome: ${client?.name || "Cliente"}
- Idade: ${client?.age || "Não informada"}
- Queixa principal / Objetivo: ${client?.hairGoal || "Revitalização capilar"}

Anamnese Técnica:
- Condição do couro cabeludo (cosmético): ${anamnese?.scalpType || "Normal"}
- Frequência de lavagem: ${anamnese?.washFrequency || "2-3x por semana"}
- Uso de calor (secador/chapinha): ${anamnese?.heatTools || "Ocasional"}
- Histórico de processos químicos: ${anamnese?.chemicalHistory?.join(", ") || "Nenhum informado"}
- Danos percebidos: ${anamnese?.perceivedDamages?.join(", ") || "Ressecamento"}

Análise Visual e Tátil (Bancada):
- Curvatura: ${visual?.curvature || "2B"}
- Espessura do fio: ${visual?.thickness || "Médio"}
- Densidade: ${visual?.density || "Média"}
- Teste de elasticidade: ${visual?.elasticity || "Moderada"}
- Teste de porosidade: ${visual?.porosity || "Alta"}
- Estado das pontas: ${visual?.endsState || "Pontas duplas"}

Pontuações calculadas pelo sistema:
- Índice de Saúde Capilar: ${scores?.overallHealth ?? 65}/100
- Necessidade de Hidratação: ${scores?.hydrationNeed ?? 70}%
- Necessidade de Nutrição: ${scores?.nutritionNeed ?? 80}%
- Necessidade de Reconstrução: ${scores?.reconstructionNeed ?? 60}%
- Condição do Couro Cabeludo: ${scores?.scalpHealth ?? 85}%

Forneça um JSON com a seguinte estrutura estrita:
{
  "summary": "Parecer cosmético profissional conciso e elegante sobre o estado da haste capilar (máximo 3 frases)",
  "professionalInsight": "Dica prática de execução técnica na bancada/lavatório para o cabeleireiro (ex: temperatura, técnica de enluvamento, acidificação, tempo de pausa)",
  "activeIngredients": ["Lista de 3 a 5 ativos cosméticos recomendados, ex: Óleo de Pracaxi, Queratina Hidrolisada, Pantenol, Ácido Lático"],
  "salonStepByStep": "Resumo de 3 passos para o protocolo imediato no salão",
  "cronogramaSchedule": ["Quatro etapas para o cronograma semanal de 1 mês, ex: Hidratação, Nutrição, Hidratação, Reconstrução"],
  "homeCareTip": "Recomendação personalizada de manutenção diária para a cliente levar para casa"
}`;

    let response: any;
    // Supported models per @google/genai guidelines: gemini-3.8-flash (primary text), gemini-3.1-flash-lite (fast fallback)
    const candidateModels = ["gemini-3.8-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"];
    let lastError: any = null;

    for (const modelName of candidateModels) {
      try {
        const aiPromise = ai.models.generateContent({
          model: modelName,
          contents: prompt,
          config: {
            responseMimeType: "application/json",
          },
        });

        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout on ${modelName}`)), 7000)
        );

        response = await Promise.race([aiPromise, timeoutPromise]);
        if (response && response.text) {
          break;
        }
      } catch (err: any) {
        lastError = err;
        // Clean informational log to avoid dumping raw JSON error objects that trigger false positive error detectors
        const status = err?.status || err?.code || (err instanceof Error ? err.message : "unavailable");
        console.log(`[AI Engine] Model ${modelName} encountered (${status}), trying alternative...`);
      }
    }

    if (!response || !response.text) {
      throw lastError || new Error("AI models temporarily busy");
    }

    const text = response.text || "{}";
    try {
      const parsed = JSON.parse(text);
      res.json({
        source: "ai",
        ...parsed,
      });
    } catch {
      res.json({
        source: "ai-raw",
        summary: text,
      });
    }
  } catch (error: any) {
    console.log("[AI Engine] Fallback to calibrated trichological expert system activated.");
    // Seamless expert fallback so salon workflow never breaks on tablet
    res.json({
      source: "expert-system",
      summary: `Avaliação cosmética para ${req.body?.client?.name || "a cliente"}: Fios com padrão de curvatura ${req.body?.visual?.curvature || "definida"}, apresentando necessidade predominante de ${req.body?.scores?.dominantNeed || "Tratamento Capilar Intensivo"}. Fibra com porosidade ${req.body?.visual?.porosity ? req.body.visual.porosity.toLowerCase() : "alterada"} e resposta elástica que demanda reposição de agentes condicionantes e proteção de cutícula.`,
      professionalInsight: "Realizar acidificação suave com pH 3.0 a 3.5 antes da máscara para selar o córtex e evitar perda de massa. Proceder com enluvamento mecha a mecha em movimentos descendentes sem atrito excessivo.",
      activeIngredients: [
        req.body?.scores?.dominantNeed === "RECONSTRUCAO" ? "Queratina Biomimética" : "Manteiga de Murumuru",
        "Ácido Lático Acidificante",
        "Pantenol (Pró-Vitamina B5)",
        "Óleo de Argan e Pracaxi",
      ],
      salonStepByStep: "1. Higienização balanceada no lavatório. 2. Acidificação e máscara de tratamento com enluvamento técnico (15 min). 3. Selagem ácida e proteção térmica sem enxágue.",
      cronogramaSchedule: [
        req.body?.scores?.dominantNeed === "RECONSTRUCAO" ? "Reconstrução" : "Nutrição Lipídica",
        "Hidratação Hídrica",
        "Nutrição Intensiva",
        "Hidratação Selante",
      ],
      homeCareTip: "Orientar a cliente a utilizar protetor térmico antes de qualquer fonte de calor e evitar água excessivamente quente no couro cabeludo e comprimento.",
    });
  }
});

// Facial & Hair Multimodal Vision Analysis (Visagismo e Leitura da Fibra)
app.post("/api/ai-hair-face-analysis", async (req, res) => {
  const { imageBase64, clientName, hairGoal } = req.body || {};

  if (!imageBase64) {
    return res.status(400).json({ error: "Nenhuma imagem foi enviada para análise." });
  }

  let cleanBase64 = imageBase64;
  let mimeType = "image/jpeg";
  const match = typeof imageBase64 === "string" ? imageBase64.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/) : null;
  if (match) {
    mimeType = match[1];
    cleanBase64 = match[2];
  }

  // Objeto neutro de referência clínica para o fallback ético:
  // Não atribui curvatura, formato de rosto ou diagnóstico sem leitura ótica confirmada.
  const neutralFallbackAnalysis = {
    curvature: "2B" as const, // Valor padrão neutro do enum para compatibilidade estrutural
    curvatureReason: "Não avaliado pela IA automática. Parâmetro requer confirmação visual ou teste de mecha pela profissional na bancada.",
    elasticity: "MEDIA" as const,
    elasticityReason: "Não avaliado pela IA automática. Realize o teste manual de tração úmida para avaliar a memória elástica da fibra.",
    porosity: "MEDIA" as const,
    porosityReason: "Não avaliado pela IA automática. Realize o teste sensorial táctil (deslize de cutículas) para confirmar a porosidade.",
    thickness: "MEDIO" as const,
    thicknessReason: "Não avaliado pela IA automática. Verifique o calibre do fio em comparação aos padrões fino, médio ou grosso.",
    density: "MEDIA" as const,
    densityReason: "Não avaliado pela IA automática. Avalie a densidade folicular e cobertura do couro cabeludo visualmente.",
    endsState: "INTEGRAS" as const,
    endsStateReason: "Não avaliado pela IA automática. Inspecione visualmente as extremidades em busca de pontas duplas ou ressecamento.",
    tensileResistance: "MODERADA" as const,
    tensileResistanceReason: "Não avaliado pela IA automática. Avalie a resistência mecânica sob leve tração na bancada.",
    touchSensation: "MACIO_SEDOSO" as const,
    touchSensationReason: "Não avaliado pela IA automática. Verifique a sensação ao toque (maciez, aspereza ou rigidez) na mecha teste.",
    frizzLevel: "MODERADO" as const,
    frizzLevelReason: "Não avaliado pela IA automática. Observe o alinhamento e a dispersão dos fios no contorno e topo.",
  };

  const buildExpertVisionResponse = (noticeReason?: string) => ({
    source: "expert-vision" as const,
    faceShape: "Pendente de Avaliação",
    facialFeatures: "Leitura facial automática indisponível no momento. Avalie proporções, linhas e contorno facial diretamente com a cliente.",
    hairCurvatureDetected: undefined,
    hairTextureDetected: "Pendente de Confirmação",
    apparentHairCondition: "Fotografia clínica anexada com sucesso. A classificação das características visuais deve ser confirmada pela profissional nas opções manuais de bancada.",
    visagismRecommendation: "Personalizar proposta de corte e harmonização com base na consulta presencial e desejo manifestado pela cliente.",
    cosmeticProtocolRecommendation: "Definir o protocolo prioritário após inspeção táctil e confirmação dos testes manuais de elasticidade e porosidade.",
    summary: noticeReason
      ? `Aviso Clínico: ${noticeReason}. Fotografia preservada no prontuário. Confirme as 9 etapas manualmente na bancada.`
      : "Aviso Clínico: Análise visual automática em modo de referência neutra. Fotografia preservada no prontuário. Confirme as 9 etapas manualmente na bancada.",
    detectedAnalysis: neutralFallbackAnalysis,
    analyzedAt: new Date().toISOString(),
  });

  const ai = getGenAI();
  if (!ai) {
    return res.json(buildExpertVisionResponse("Chave de IA não configurada no servidor"));
  }

  // Verificação de cota temporária (Rate Limit / Quota Circuit Breaker)
  // Se detectamos recentemente que a cota da chave está esgotada (429), evita chamadas infrutíferas
  const now = Date.now();
  if ((globalThis as any).__GEMINI_QUOTA_EXHAUSTED_UNTIL && now < (globalThis as any).__GEMINI_QUOTA_EXHAUSTED_UNTIL) {
    const remainingSec = Math.ceil(((globalThis as any).__GEMINI_QUOTA_EXHAUSTED_UNTIL - now) / 1000);
    console.log(`[AI Vision Engine] Cota de IA previamente esgotada (429 RESOURCE_EXHAUSTED). Circuit breaker ativo por mais ${remainingSec}s. Acionando fallback neutro imediato.`);
    return res.json(buildExpertVisionResponse("Cota diária da API de IA temporariamente excedida (429 RESOURCE_EXHAUSTED)"));
  }

  try {
    const imagePart = {
      inlineData: {
        mimeType,
        data: cleanBase64,
      },
    };

    const prompt = `Você é uma especialista de renome em Visagismo Capilar e Tricologia Cosmética de Salão atuando no aplicativo "CAPILAR SMART IA" (Projeto Integrador SENAC).
Analise a imagem da cliente fornecida ${clientName ? `(Cliente: ${clientName})` : ""}${hairGoal ? ` com o objetivo capilar: "${hairGoal}"` : ""}.

DIRETRIZES ESTRITAS:
- NÃO forneça diagnósticos médicos, clínicos ou dermatológicos de patologias (sem termos de doenças ou prescrições médicas).
- Concentre-se estritamente na harmonia facial estética (visagismo) e nas características cosmetológicas da haste capilar observáveis na imagem.

Avalie com rigor técnico e preencha TODAS as 9 etapas da análise capilar segundo a Tabela Internacional e protocolos de bancada:
1. Curvatura da Fibra (1A a 4C): Escolha EXATAMENTE um entre: "1A", "1B", "1C", "2A", "2B", "2C", "3A", "3B", "3C", "4A", "4B", "4C".
2. Teste de Elasticidade: Escolha EXATAMENTE um entre: "SAUDAVEL", "MEDIA", "BAIXA_EMBORRACHADO".
3. Teste de Porosidade: Escolha EXATAMENTE um entre: "BAIXA", "MEDIA", "ALTA".
4. Espessura do Fio: Escolha EXATAMENTE um entre: "FINO", "MEDIO", "GROSSO".
5. Densidade Capilar: Escolha EXATAMENTE um entre: "BAIXA", "MEDIA", "ALTA".
6. Estado das Pontas: Escolha EXATAMENTE um entre: "INTEGRAS", "RESSECADAS", "DUPLAS", "MULTIPLAS_ESFARELADAS".
7. Resistência à Tração: Escolha EXATAMENTE um entre: "BOA_RESISTENTE", "MODERADA", "FRAGIL_QUEBRADICO".
8. Toque e Aspecto: Escolha EXATAMENTE um entre: "MACIO_SEDOSO", "ASPERO_RIGIDO", "RESSECADO_OPOCO", "FRAGIL_QUEBRADICO".
9. Frizz & Alinhamento: Escolha EXATAMENTE um entre: "LEVE", "MODERADO", "INTENSO".

Preencha também a leitura de visagismo facial:
- "faceShape": Formato facial predominante ("Oval", "Redondo", "Quadrado", "Coração", "Diamante", "Alongado" ou "Triangular").
- "facialFeatures": Análise técnica dos terços e linhas do rosto.
- "visagismRecommendation": Recomendação de corte e franja para o formato do rosto.
- "cosmeticProtocolRecommendation": Tratamento de salão prioritário sugerido.
- "summary": Parecer técnico resumido em 2 frases para a profissional.

Retorne EXCLUSIVAMENTE um objeto JSON válido com a seguinte estrutura:
{
  "faceShape": "...",
  "facialFeatures": "...",
  "hairCurvatureDetected": "2B",
  "hairTextureDetected": "Médio",
  "apparentHairCondition": "...",
  "visagismRecommendation": "...",
  "cosmeticProtocolRecommendation": "...",
  "summary": "...",
  "detectedAnalysis": {
    "curvature": "2B",
    "curvatureReason": "justificativa visual técnica curta",
    "elasticity": "MEDIA",
    "elasticityReason": "justificativa visual técnica curta",
    "porosity": "ALTA",
    "porosityReason": "justificativa visual técnica curta",
    "thickness": "MEDIO",
    "thicknessReason": "justificativa visual técnica curta",
    "density": "MEDIA",
    "densityReason": "justificativa visual técnica curta",
    "endsState": "DUPLAS",
    "endsStateReason": "justificativa visual técnica curta",
    "tensileResistance": "MODERADA",
    "tensileResistanceReason": "justificativa visual técnica curta",
    "touchSensation": "ASPERO_RIGIDO",
    "touchSensationReason": "justificativa visual técnica curta",
    "frizzLevel": "MODERADO",
    "frizzLevelReason": "justificativa visual técnica curta"
  }
}`;

    let response: any = null;
    let timerId: any = null;
    // Cancelamento real via AbortController suportado nativamente pelo @google/genai (abortSignal em config)
    const abortController = new AbortController();

    try {
      const aiPromise = ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: {
          parts: [imagePart, { text: prompt }],
        },
        config: {
          responseMimeType: "application/json",
          abortSignal: abortController.signal,
        },
      });

      const timeoutPromise = new Promise((_, reject) => {
        timerId = setTimeout(() => {
          // Dispara cancelamento real da chamada HTTP no SDK do Gemini ao atingir 8 segundos
          try {
            abortController.abort();
          } catch {
            // guarda contra falha de abort
          }
          reject(new Error("Timeout on gemini-3.8-flash (8s limit)"));
        }, 8000);
      });

      response = await Promise.race([aiPromise, timeoutPromise]);
      if (timerId) clearTimeout(timerId);
    } catch (err: any) {
      if (timerId) clearTimeout(timerId);
      const status = err?.status || err?.code || (err instanceof Error ? err.message : "unavailable");
      const isQuotaExhausted =
        err?.status === 429 ||
        err?.code === 429 ||
        (typeof err?.message === "string" &&
          (err.message.includes("429") || err.message.includes("RESOURCE_EXHAUSTED") || err.message.includes("quota")));

      if (isQuotaExhausted) {
        // Ativa circuit breaker por 60 segundos para evitar chamadas fúteis à API
        (globalThis as any).__GEMINI_QUOTA_EXHAUSTED_UNTIL = Date.now() + 60000;
        console.log(`[AI Vision Engine] Erro 429 (RESOURCE_EXHAUSTED). Circuit breaker ativado por 60s.`);
        return res.json(buildExpertVisionResponse("Cota da API de IA temporariamente esgotada (429). Aguarde renovação ou confirme manualmente"));
      }

      const isAborted = err?.name === "AbortError" || (typeof err?.message === "string" && err.message.includes("aborted"));
      if (isAborted) {
        console.log(`[AI Vision Engine] Chamada cancelada com sucesso via AbortSignal após atingir o limite estrito de 8s.`);
        return res.json(buildExpertVisionResponse("Tempo limite de resposta de visão atingido (8s). Chamada abortada no servidor"));
      }

      console.log(`[AI Vision Engine] Chamada Gemini Vision falhou (${status}). Acionando fallback neutro imediato.`);
      response = null;
    }

    // Se o Gemini não respondeu ou falhou sem ser 429/timeout já tratado
    if (!response || !response.text) {
      return res.json(buildExpertVisionResponse("Análise automática indisponível"));
    }

    const text = response.text || "{}";
    const parsed = JSON.parse(text);

    // Normalização completa dos 9 parâmetros clínicos da bancada
    const rawAnalysis = parsed.detectedAnalysis || {};
    const detectedAnalysis = {
      curvature: rawAnalysis.curvature || parsed.hairCurvatureDetected || neutralFallbackAnalysis.curvature,
      curvatureReason: rawAnalysis.curvatureReason || "Padrão de curvatura identificado visualmente pela IA.",
      elasticity: rawAnalysis.elasticity || neutralFallbackAnalysis.elasticity,
      elasticityReason: rawAnalysis.elasticityReason || "Avaliação de elasticidade aparente identificada pela IA.",
      porosity: rawAnalysis.porosity || neutralFallbackAnalysis.porosity,
      porosityReason: rawAnalysis.porosityReason || "Nível de reflexão e dispersão de luz na haste avaliado pela IA.",
      thickness: rawAnalysis.thickness || neutralFallbackAnalysis.thickness,
      thicknessReason: rawAnalysis.thicknessReason || "Calibre estimado da fibra capilar.",
      density: rawAnalysis.density || neutralFallbackAnalysis.density,
      densityReason: rawAnalysis.densityReason || "Volume e cobertura visual da mecha e couro cabeludo.",
      endsState: rawAnalysis.endsState || neutralFallbackAnalysis.endsState,
      endsStateReason: rawAnalysis.endsStateReason || "Integridade observada nas pontas das mechas.",
      tensileResistance: rawAnalysis.tensileResistance || neutralFallbackAnalysis.tensileResistance,
      tensileResistanceReason: rawAnalysis.tensileResistanceReason || "Índice visual de resistência estimado.",
      touchSensation: rawAnalysis.touchSensation || neutralFallbackAnalysis.touchSensation,
      touchSensationReason: rawAnalysis.touchSensationReason || "Textura e maleabilidade visual observadas.",
      frizzLevel: rawAnalysis.frizzLevel || neutralFallbackAnalysis.frizzLevel,
      frizzLevelReason: rawAnalysis.frizzLevelReason || "Grau de desalinhamento de fios observado na imagem.",
    };

    return res.json({
      source: "ai",
      ...parsed,
      hairCurvatureDetected: detectedAnalysis.curvature,
      detectedAnalysis,
      analyzedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.log("[AI Vision Engine] Fallback emergencial para sistema especialista neutro.");
    return res.json(buildExpertVisionResponse("Falha no processamento da imagem"));
  }
});

// =========================================================================
// FASE 4.2: FIREBASE ADMIN, RATE LIMITING ATÔMICO E STREAMING SEGURO DE ORIGINAIS
// =========================================================================

const MAX_CLINICAL_ORIGINAL_BYTES = 26_214_400; // 25 MiB

let firebaseAdminApp: App | null = null;
function getFirebaseAdmin(): App {
  if (firebaseAdminApp) return firebaseAdminApp;
  const existingApps = getApps();
  if (existingApps.length > 0 && existingApps[0]) {
    firebaseAdminApp = existingApps[0];
    return firebaseAdminApp;
  }

  const projectId =
    process.env.FIREBASE_PROJECT_ID ||
    process.env.GCLOUD_PROJECT ||
    "capilar-smart-ia-test";
  const storageBucket =
    process.env.FIREBASE_STORAGE_BUCKET || `${projectId}.appspot.com`;

  if (process.env.FIREBASE_SERVICE_ACCOUNT_KEY) {
    try {
      const cred = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
      firebaseAdminApp = initializeApp({
        credential: cert(cred),
        projectId,
        storageBucket,
      });
      return firebaseAdminApp;
    } catch (e) {
      console.warn("[Firebase Admin] Falha ao parsear chave de serviço:", e);
    }
  }

  firebaseAdminApp = initializeApp({
    projectId,
    storageBucket,
  });
  return firebaseAdminApp;
}

/**
 * Controle Distribuído e Atômico de Limite de Requisições por UID (Fase 4.2)
 * Executa transação com isolamento serializável no Firestore para evitar concorrência no Cloud Run.
 * Política Estrita: FAIL-CLOSED (bloqueia o download se o Firestore estiver inacessível).
 */
async function checkDistributedRateLimit(
  callerUid: string
): Promise<{ allowed: boolean; retryAfterSeconds?: number; reason?: string }> {
  try {
    const adminApp = getFirebaseAdmin();
    const firestore = getFirestore(adminApp);
    const docRef = firestore.collection("rate_limits_originals").doc(callerUid);
    const now = Date.now();
    const windowMs = 60 * 1000; // Janela deslizante de 60 segundos
    const maxRequests = 10;     // Máximo 10 downloads de originais / minuto

    const result = await firestore.runTransaction(async (transaction: any) => {
      const snap = await transaction.get(docRef);
      let timestamps: number[] = [];

      if (snap.exists) {
        const data = snap.data();
        if (Array.isArray(data?.timestamps)) {
          // Filtra timestamps da janela deslizante atual
          timestamps = data.timestamps.filter(
            (ts: number) => typeof ts === "number" && now - ts < windowMs
          );
        }
      }

      if (timestamps.length >= maxRequests) {
        const oldestInWindow = Math.min(...timestamps);
        const retryAfterSeconds = Math.max(
          1,
          Math.ceil((oldestInWindow + windowMs - now) / 1000)
        );
        return {
          allowed: false,
          retryAfterSeconds,
          reason: "Limite de downloads de laudos originais por minuto excedido.",
        };
      }

      timestamps.push(now);
      transaction.set(
        docRef,
        {
          professionalId: callerUid,
          timestamps,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );

      return { allowed: true };
    });

    return result;
  } catch (err) {
    console.error("[RateLimiter] Erro ao validar transação no Firestore (FAIL-CLOSED):", err);
    // POLÍTICA FAIL-CLOSED: Qualquer falha bloqueia o download
    return {
      allowed: false,
      retryAfterSeconds: 30,
      reason: "Serviço de validação de segurança e taxa temporariamente indisponível. Download bloqueado.",
    };
  }
}

/**
 * Rota Segura de Streaming de Fotografias Originais (/api/photos/:photoId/original)
 * - Autenticação: Firebase ID Token com verificação de revogação em tempo real (checkRevoked: true)
 * - Titularidade Quádrupla no Firestore: Profissional, Cliente, Avaliação e Foto
 * - Validação Física do Caminho: Anti-traversal e Anti-SSRF
 * - Limite Estrito: 25 MiB (26.214.400 bytes)
 * - Encerramento Normal vs Interrupção Prematura pelo Cliente (writableFinished)
 */
app.get("/api/photos/:photoId/original", async (req, res) => {
  const { photoId } = req.params;

  if (!photoId || typeof photoId !== "string") {
    return res.status(400).json({ error: "Identificador photoId inválido." });
  }

  // 1. Verificação do Cabeçalho de Autorização Bearer
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      error: "Autorização obrigatória. Forneça o Firebase ID Token no cabeçalho Authorization.",
    });
  }

  const token = authHeader.split("Bearer ")[1]?.trim();
  if (!token) {
    return res.status(401).json({ error: "Token de autenticação não fornecido." });
  }

  let callerUid = "";
  try {
    const adminApp = getFirebaseAdmin();
    // Validação estrita de ID token com verificação de sessão revogada (checkRevoked: true)
    const decodedToken = await getAuth(adminApp).verifyIdToken(token, true);
    callerUid = decodedToken.uid;
    if (!callerUid) {
      return res.status(401).json({ error: "Token inválido: UID ausente." });
    }
  } catch (authError: any) {
    if (authError?.code === "auth/id-token-revoked") {
      return res.status(401).json({
        error: "Sessão revogada. Por favor, autentique-se novamente.",
        code: "auth/id-token-revoked",
      });
    }
    return res.status(401).json({
      error: "Falha na autenticação do token Firebase.",
      details: authError instanceof Error ? authError.message : "Token inválido.",
    });
  }

  // 2. Avaliação de Limite Distribuído Atômico (Fail-Closed)
  const rateLimit = await checkDistributedRateLimit(callerUid);
  if (!rateLimit.allowed) {
    res.setHeader("Retry-After", String(rateLimit.retryAfterSeconds || 60));
    return res.status(429).json({
      error: rateLimit.reason || "Muitas requisições de originais. Aguarde antes de tentar novamente.",
      retryAfterSeconds: rateLimit.retryAfterSeconds,
    });
  }

  try {
    const adminApp = getFirebaseAdmin();
    const firestore = getFirestore(adminApp);

    // 3. Consulta do Metadado da Foto na Coleção Raiz /photos/{photoId}
    const photoDoc = await firestore.collection("photos").doc(photoId).get();
    if (!photoDoc.exists) {
      return res.status(404).json({ error: "Registro fotográfico não encontrado no prontuário." });
    }

    const photo = photoDoc.data();
    if (!photo) {
      return res.status(404).json({ error: "Metadados da fotografia inexistentes." });
    }

    // 4. Validação de Titularidade da Profissional
    if (photo.professionalId !== callerUid) {
      console.warn(`[Security] Tentativa de acesso cruzado bloqueada: caller=${callerUid}, owner=${photo.professionalId}`);
      return res.status(403).json({ error: "Acesso negado: Você não possui permissão para este registro." });
    }

    // 5. Validação de Titularidade da Cliente (/clients/{clientId})
    if (!photo.clientId) {
      return res.status(400).json({ error: "Fotografia sem vínculo com cliente registrado." });
    }
    const clientDoc = await firestore.collection("clients").doc(photo.clientId).get();
    if (!clientDoc.exists) {
      return res.status(404).json({ error: "Cliente associada não localizada no sistema." });
    }
    const clientData = clientDoc.data();
    if (clientData?.professionalId !== callerUid) {
      return res.status(403).json({ error: "Acesso negado: A cliente vinculada pertence a outra profissional." });
    }

    // 6. Validação da Avaliação Vinculada (quando houver evaluationId)
    if (photo.evaluationId) {
      const evalDoc = await firestore.collection("evaluations").doc(photo.evaluationId).get();
      if (!evalDoc.exists) {
        return res.status(403).json({ error: "Acesso negado: Avaliação referenciada não encontrada." });
      }
      const evalData = evalDoc.data();
      if (evalData?.professionalId !== callerUid || evalData?.clientId !== photo.clientId) {
        return res.status(403).json({
          error: "Acesso negado: A avaliação vinculada não pertence a esta cliente ou profissional.",
        });
      }
    }

    // 7. Independência de Consentimentos LGPD (Prontuário vs Divulgação / IA)
    // A revogação de divulgação ou IA NÃO impede o acesso clínico legítimo ao prontuário.
    // Somente exclusão autorizada do prontuário com retenção cancelada bloquearia.
    if (photo.consentRecordId) {
      const consentDoc = await firestore.collection("consents").doc(photo.consentRecordId).get();
      if (consentDoc.exists) {
        const consentData = consentDoc.data();
        if (consentData?.deletionStatus === "EXCLUSION_AUTHORIZED") {
          return res.status(410).json({ error: "Fotografia excluída mediante termo formal de revogação." });
        }
      }
    }

    // 8. Priorização do Caminho Original (Anti-Degradação e Anti-Travessia)
    let targetStoragePath = photo.originalStoragePath;
    if (!targetStoragePath && photo.storagePath) {
      if (photo.storagePath.includes("/originals/") || photo.storagePath.includes("_orig.")) {
        targetStoragePath = photo.storagePath;
      }
    }

    if (!targetStoragePath) {
      return res.status(404).json({
        error: "Arquivo original não registrado para esta fotografia clínica.",
      });
    }

    // Validação estrita do prefixo canônico de storage
    const expectedPrefix = `photos/${callerUid}/clients/${photo.clientId}/`;
    if (!targetStoragePath.startsWith(expectedPrefix)) {
      console.warn(`[Security] Caminho de storage inconsistente rejeitado: ${targetStoragePath}`);
      return res.status(403).json({ error: "Estrutura de caminho de arquivo não autorizada." });
    }

    if (
      targetStoragePath.includes("..") ||
      targetStoragePath.includes("//") ||
      targetStoragePath.includes("\\") ||
      targetStoragePath.includes("\0")
    ) {
      return res.status(400).json({ error: "Caminho malicioso rejeitado." });
    }

    // 9. Validação no Bucket Oficial do Firebase Storage
    const bucket = getStorage(adminApp).bucket();
    const file = bucket.file(targetStoragePath);
    const [exists] = await file.exists();
    if (!exists) {
      return res.status(404).json({ error: "Arquivo original físico não encontrado no armazenamento." });
    }

    const [metadata] = await file.getMetadata();
    const fileSize = Number(metadata.size || 0);

    // Validação estrita do limite padronizado de 25 MiB (26.214.400 bytes)
    if (fileSize > MAX_CLINICAL_ORIGINAL_BYTES) {
      return res.status(413).json({
        error: `Arquivo original de ${fileSize} bytes excede o limite máximo permitido de 25 MiB (${MAX_CLINICAL_ORIGINAL_BYTES} bytes).`,
      });
    }

    // 10. Configuração dos Cabeçalhos de Resposta Segura
    const safeId = photoId.replace(/[^a-zA-Z0-9_-]/g, "");
    const extMatch = targetStoragePath.match(/\.([a-zA-Z0-9]+)$/);
    const safeExt = extMatch ? extMatch[1].toLowerCase() : "jpg";
    const filename = `laudo_original_${safeId}.${safeExt}`;

    let contentType = metadata.contentType || "image/jpeg";
    if (safeExt === "webp") contentType = "image/webp";
    if (safeExt === "png") contentType = "image/png";

    res.setHeader("Content-Type", contentType);
    res.setHeader("Content-Length", String(fileSize));
    res.setHeader("Cache-Control", "private, no-cache, no-store, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);

    // 11. Streaming Controlado: Distinção Clara entre Conclusão Normal e Desconexão Prematura
    const readStream = file.createReadStream();
    let streamFinishedNormally = false;

    readStream.on("end", () => {
      streamFinishedNormally = true;
    });

    readStream.on("error", (err: any) => {
      if (!res.headersSent) {
        res.status(500).json({ error: "Falha durante transmissão do arquivo original." });
      } else {
        res.destroy(err);
      }
    });

    req.on("close", () => {
      // Somente destrói o stream se a transmissão NÃO terminou normalmente e a resposta não foi concluída
      if (!streamFinishedNormally && !res.writableFinished && !res.writableEnded) {
        readStream.destroy();
        console.warn(`[Streaming] Conexão cancelada prematuramente pelo cliente: photoId=${photoId}`);
      }
    });

    readStream.pipe(res);
  } catch (error: any) {
    console.error("[PhotosAPI] Erro ao processar download de original:", error);
    if (!res.headersSent) {
      return res.status(500).json({
        error: "Erro interno no servidor ao preparar download seguro.",
      });
    }
    res.end();
  }
});

// Vite middleware & Static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CAPILAR SMART IA Server rodando em http://localhost:${PORT}`);
  });
}

startServer();
